<?php
$host = "localhost";
$user = "root";
$pass = "";
$db = "pemesanan";

$db = new mysqli($host, $user, $pass, $db);