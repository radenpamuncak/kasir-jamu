<?php include 'navbar.php' ?>

<style>
    .card-img {
        width: 100%;
        height: 400px;
        object-fit: cover;
    }
</style>
<div class="row">
    <div class="col-md-4 p-2">
        <form action="index.php" method="post">
        <div class="card shadow text-center">
            <img class="card-img" src="https://s1.bukalapak.com/img/15122407311/large/JAMU_ASAM_URAT_TAWON_ASAM_URAT__REMATIK__DLL.jpg" alt="">
            <div class="card-body bg-dark text-white">
            <BUtton type="text" class="btn btn-dark">JAMU ASAM</BUtton>
            
            </div>
        </div>
    </div>
    <div class="col-md-4 p-2">
        <div class="card shadow text-center">
            <img class="card-img" src="https://www.static-src.com/wcsstore/Indraprastha/images/catalog/full//99/MTA-2568276/jamu-jago_jamu-jago-diabeta-obat-diabetes-alami--40-kapsul-_full03.jpg" alt="">
            <div class="card-body bg-dark text-white">
            <BUtton type="text" class="btn btn-dark">JAMU DIABETES</BUtton>
            </div>
        </div>
    </div>
    <div class="col-md-4 p-2">
        <div class="card shadow text-center">
            <img class="card-img" src="https://img.goapotik.com/mediums/PIL%20RAHIM%20SEHAT%201.jpg" alt="">
            <div class="card-body bg-dark text-white">
            <BUtton type="text" class="btn btn-dark">JAMU RAHIM</BUtton>
            </div>
        </div>
    </div>
    <div class="col-md-4 p-2">
        <div class="card shadow text-center">
            <img class="card-img" src="https://cf.shopee.co.id/file/ae5c489b59d77c201188aa5b83fb4f8c" alt="">
            <div class="card-body bg-dark text-white">
            <BUtton type="text" class="btn btn-dark">JAMU PELURUH</BUtton>
            </div>
        </div>
    </div>
    <div class="col-md-4 p-2">
        <div class="card shadow text-center">
            <img class="card-img" src="https://www.static-src.com/wcsstore/Indraprastha/images/catalog/full//86/MTA-2610481/dami_dami-jamu-godogan-obat-infeksi-kandungan-tradisional--2-pcs-_full04.jpg" alt="">
            <div class="card-body bg-dark text-white">
            <BUtton type="text" class="btn btn-dark">JAMU INFEKSI</BUtton>
</div>
        </div>
    </div>
    <div class="col-md-4 p-2">
        <div class="card shadow text-center">
            <img class="card-img" src="https://images.tokopedia.net/img/cache/500-square/product-1/2020/8/16/725209/725209_c4961708-59a7-4537-8983-5d4938bcb458_584_584" alt="">
            <div class="card-body bg-dark text-white">
            <BUtton type="text" class="btn btn-dark">JAMU AMBEYEN</BUtton>
</div>
        </div>
    </div>
    <div class="col-md-4 p-2">
        <div class="card shadow text-center">
            <img class="card-img" src="https://images.tokopedia.net/img/cache/500-square/VqbcmM/2021/2/7/549c98e7-0b56-4433-8a17-91f693124eb7.jpg" alt="">
            <div class="card-body bg-dark text-white">
            <BUtton type="text" class="btn btn-dark">JAMU KANKER</BUtton>
</div>
        </div>
    </div>
    <div class="col-md-4 p-2">
        <div class="card shadow text-center">
            <img class="card-img" src="https://www.static-src.com/wcsstore/Indraprastha/images/catalog/full//82/MTA-10061017/sehat_wanita_sehat_wanita_obat_herbal_kista_ovarium_-_penghancur_kista_-_penghilang_kista__full01_ejndl74r.jpg" alt="">
            <div class="card-body bg-dark text-white">
            <BUtton type="text" class="btn btn-dark">JAMU KISTA</BUtton>
</div>
        </div>
    </div>
    <div class="col-md-4 p-2">
        <div class="card shadow text-center">
            <img class="card-img" src="https://www.sidomunculstore.com/upload/product/sido-muncul-jamu-ulu-hati-10s-mengurangi-nyeri-lambung-maag-perih-20210206025408-1.jpg" alt="">
            <div class="card-body bg-dark text-white">
            <BUtton type="text" class="btn btn-dark">JAMU LAMBUNG</BUtton>
</div>
        </div>
        </form>
    </div>
   
</div>

<?php include 'footer.php' ?>