<?php include 'navbar.php' ?>

<div class="card card-body text-dark mb-4 " style="font-size: 40px;">
    <marquee behavior="" direction="">SELAMAT DATANG DI TOKO KAMI,SEMANGAT</marquee>
</div>
<img style="width: 100%;"src="https://i.pinimg.com/564x/ac/75/20/ac7520d8837c96f3a6c942e17171bad9.jpg" alt="">
<?php include 'footer.php'?>
