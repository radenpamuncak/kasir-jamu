<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>kasir jamu</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css">
    <link rel="icon" href="https://png.pngtree.com/png-vector/20200109/ourlarge/pngtree-acupuncture-logo-design-vector-alternative-therapy-sign-chines-png-image_2112102.jpg">
    <script src="https://cdn.tailwindcss.com"></script>
    <body>
    <div class="container-fluid">
        </div>
    </body>
    <style>
        body {
            background-size: cover;
        }
    </style>
</head>
<body background="jamu.jpg" class="row p-5 justify-content-center">
    <div class="col-4">
        <a style="font-size: 30px !important; color: blue-bold" class="w-full block text-center" href="aksilogin.php">
        
        </a>
        <div class="bg-white">
  <div class="card-body">
<form action="home.php">
  <div class="form-group">
    <label for="staticEmail2">Email</label>
    <input type="text" class="form-control mb-3" id="staticEmail2" placeholder="masukkan email">
  </div>
  <div class="form-group">
    <label for="inputPassword2">Password</label>
    <input type="password" class="form-control mb-3" id="inputPassword2" placeholder="Password">
  </div>
  <div class="form-group">
    <button type="submit" class="bg-blue-500 btn btn-primary mb-3">login</button>
  </div>
</form>
  </div>
</div>
</body>
</html>